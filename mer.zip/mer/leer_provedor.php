<?php 
include('conexion.php');
// get the contents of the JSON 
define('JSON', 'providers-merqueo.json');
define('JSONlocal', 'providers-merqueo.json');
// leer JSON validamos si el fichero online e accesible y si no abrimos el json local
if($data = @file_get_contents(JSON)){
	$items = json_decode($data, true);
}
else{
	$data = file_get_contents(JSONlocal);
	$items = json_decode($data, true);
}
//lista de items a recorrer
$listaItems = $items["directorios"]["providers"];


//bucle para recorrer los elementos del array
	for ($i = 0; $i<count($listaItems); $i++){
		
		$id= $listaItems[$i]['id'];
		
		$name=$listaItems[$i]['name'];
		
	$productId= $listaItems[$i]['productId'];
		
		
		
	
//Insert the fetched Data into Database 
$sql = "INSERT INTO providers(id, name, productId) VALUES('$id', '$name', '$productId')";
$qry_code = utf8_decode($sql);
$result = mysql_query($qry_code) or die(mysql_error());
	}
	
echo'hecho';	
?>