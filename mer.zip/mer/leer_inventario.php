<?php 
include('conexion.php');
// get the contents of the JSON 
define('JSON', 'inventory-merqueo.json');
define('JSONlocal', 'inventory-merqueo.json');
// leer JSON validamos si el fichero online e accesible y si no abrimos el json local
if($data = @file_get_contents(JSON)){
	$items = json_decode($data, true);
}
else{
	$data = file_get_contents(JSONlocal);
	$items = json_decode($data, true);
}
//lista de items a recorrer
$listaItems = $items["directorios"]["inventory"];

//bucle para recorrer los elementos del array
	for ($i = 0; $i<count($listaItems); $i++){
		 $quantity=$listaItems[$i]['quantity'];
		
		$date= $listaItems[$i]['date'];
		
		$id= $listaItems[$i]['id'];
		
	
//Inserta datos en Database 
$sql = "INSERT INTO inventory(id, quantity, date) VALUES('$id', '$quantity', '$date')";
$qry_code = utf8_decode($sql);
$result = mysql_query($qry_code) or die(mysql_error());
	}
echo'hecho';	
?>