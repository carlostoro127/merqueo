<?php 
include('conexion.php');
// get the contents of the JSON 
define('JSON', 'orders-merqueo.json');
define('JSONlocal', 'orders-merqueo.json');
// leer JSON validamos si el fichero online e accesible y si no abrimos el json local
if($data = @file_get_contents(JSON)){
	$items = json_decode($data, true);
}
else{
	$data = file_get_contents(JSONlocal);
	$items = json_decode($data, true);
}
//lista de items a recorrer
$listaItems = $items["directorios"]["orders"];


//bucle para recorrer los elementos del array
	for ($i = 0; $i<count($listaItems); $i++){
		
		$id= $listaItems[$i]['id'];
		
		$priority=$listaItems[$i]['priority'];
		
	$address= $listaItems[$i]['address'];
	$user= $listaItems[$i]['user'];
	$name= $listaItems[$i]['name'];
	$quantity= $listaItems[$i]['quantity'];
	$deliveryDate= $listaItems[$i]['deliveryDate'];
	$productsid= $listaItems[$i]['productsid'];
	
		
		
		
	
//Insert the fetched Data into Database 
$sql = "INSERT INTO orders(id, priority, address, user, productsid, name, quantity, deliveryDate) VALUES('$id', '$priority', '$address', '$user', '$productsid', '$name', '$quantity', '$deliveryDate')";
$qry_code = utf8_decode($sql);
$result = mysql_query($qry_code) or die(mysql_error());
	}
	
echo'hecho';	
?>