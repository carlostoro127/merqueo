-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2020 at 11:48 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `json`
--

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE IF NOT EXISTS `inventory` (
  `id` varchar(25) NOT NULL,
  `quantity` varchar(25) NOT NULL,
  `date` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `quantity`, `date`) VALUES
('1', '3', '2019-03-01'),
('2', '3', '2019-03-01'),
('3', '7', '2019-03-01'),
('4', '8', '2019-03-01'),
('5', '10', '2019-03-01'),
('6', '15', '2019-03-01'),
('7', '26', '2019-03-01'),
('8', '11', '2019-03-01'),
('9', '1', '2019-03-01'),
('10', '8', '2019-03-01'),
('11', '7', '2019-03-01'),
('12', '8', '2019-03-01'),
('13', '2', '2019-03-01'),
('14', '1', '2019-03-01'),
('15', '1', '2019-03-01'),
('16', '9', '2019-03-01'),
('17', '17', '2019-03-01'),
('18', '8', '2019-03-01'),
('19', '9', '2019-03-01'),
('20', '9', '2019-03-01'),
('21', '3', '2019-03-01'),
('22', '6', '2019-03-01'),
('23', '9', '2019-03-01'),
('24', '9', '2019-03-01'),
('25', '10', '2019-03-01'),
('26', '40', '2019-03-01'),
('27', '2', '2019-03-01'),
('28', '3', '2019-03-01'),
('29', '2', '2019-03-01'),
('30', '1', '2019-03-01'),
('31', '9', '2019-03-01'),
('32', '10', '2019-03-01'),
('33', '2', '2019-03-01'),
('34', '3', '2019-03-01'),
('35', '3', '2019-03-01'),
('36', '6', '2019-03-01');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` varchar(25) NOT NULL,
  `priority` varchar(25) NOT NULL,
  `address` varchar(25) NOT NULL,
  `user` varchar(25) NOT NULL,
  `productsid` varchar(25) NOT NULL,
  `name` varchar(25) NOT NULL,
  `quantity` varchar(25) NOT NULL,
  `deliveryDate` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `priority`, `address`, `user`, `productsid`, `name`, `quantity`, `deliveryDate`) VALUES
('1', '1', 'KR 14 # 87 - 20 ', 'Sofia', '1', 'Leche', '1', '2019-03-01'),
('1', '1', 'KR 14 # 87 - 20 ', 'Sofia', '2', 'Huevos', '21', '2019-03-01'),
('1', '1', 'KR 14 # 87 - 20 ', 'Sofia', '37', 'Pan Bimbo', '7', '2019-03-01'),
('1', '1', 'KR 14 # 87 - 20 ', 'Sofia', '3', 'Manzana Verde', '10', '2019-03-01'),
('1', '1', 'KR 14 # 87 - 20 ', 'Sofia', '4', 'Pepino Cohombro', '5', '2019-03-01'),
('2', '1', 'KR 20 # 164A - 5 ', 'Angel', '5', 'Pimentón Rojo', '100', '2019-03-01'),
('2', '1', 'KR 20 # 164A - 5 ', 'Angel', '6', 'Kiwi', '60', '2019-03-01'),
('3', '3', 'KR 13 # 74 - 38 ', 'Hocks', '7', 'Cebolla Cabezona Blanca L', '4', '2019-03-01'),
('3', '3', 'KR 13 # 74 - 38 ', 'Hocks', '8', 'Habichuela', '3', '2019-03-01'),
('3', '3', 'KR 13 # 74 - 38 ', 'Hocks', '9', 'Mango Tommy Maduro', '4', '2019-03-01'),
('3', '3', 'KR 13 # 74 - 38 ', 'Hocks', '10', 'Tomate Chonto Pintón', '8', '2019-03-01'),
('3', '3', 'KR 13 # 74 - 38 ', 'Hocks', '11', 'Zanahoria Grande', '5', '2019-03-01'),
('4', '1', 'CL 93 # 12 - 9 ', 'Michael', '12', 'Aguacate Maduro', '3', '2019-03-01'),
('4', '1', 'CL 93 # 12 - 9 ', 'Michael', '13', 'Kale o Col Rizada', '2', '2019-03-01'),
('4', '1', 'CL 93 # 12 - 9 ', 'Michael', '14', 'Cebolla Cabezona Roja Lim', '4', '2019-03-01'),
('4', '1', 'CL 93 # 12 - 9 ', 'Michael', '4', 'Pepino Cohombro', '2', '2019-03-01'),
('4', '1', 'CL 93 # 12 - 9 ', 'Michael', '15', 'Tomate Chonto Maduro', '3', '2019-03-01'),
('5', '1', 'CL 71 # 3 - 74 ', 'Bar de Alex', '16', 'Acelga', '1500', '2019-03-01'),
('6', '2', 'KR 20 # 134A - 5 ', 'Sabor Criollo', '17', 'Espinaca Bogotana x 500gr', '2', '2019-03-01'),
('6', '2', 'KR 20 # 134A - 5 ', 'Sabor Criollo', '18', 'Ahuyama', '3', '2019-03-01'),
('6', '2', 'KR 20 # 134A - 5 ', 'Sabor Criollo', '15', 'Tomate Chonto Maduro', '2', '2019-03-01'),
('6', '2', 'KR 20 # 134A - 5 ', 'Sabor Criollo', '19', 'Cebolla Cabezona Blanca S', '2', '2019-03-01'),
('6', '2', 'KR 20 # 134A - 5 ', 'Sabor Criollo', '20', 'Melón', '3', '2019-03-01'),
('7', '2', 'CL 80 # 14 - 38 ', 'El Pollo Rojo', '21', 'Cebolla Cabezona Roja Sin', '3', '2019-03-01'),
('7', '2', 'CL 80 # 14 - 38 ', 'El Pollo Rojo', '22', 'Cebolla Larga Junca x 500', '2', '2019-03-01'),
('7', '2', 'CL 80 # 14 - 38 ', 'El Pollo Rojo', '23', 'Hierbabuena x 500grs', '2', '2019-03-01'),
('7', '2', 'CL 80 # 14 - 38 ', 'El Pollo Rojo', '39', 'Lechuga Crespa Morada', '4', '2019-03-01'),
('7', '2', 'CL 80 # 14 - 38 ', 'El Pollo Rojo', '24', 'Lechuga Crespa Verde', '15', '2019-03-01'),
('8', '7', 'KR 14 # 98 - 74 ', 'All Salad', '25', 'Limón Tahití', '3', '2019-03-01'),
('8', '7', 'KR 14 # 98 - 74 ', 'All Salad', '26', 'Mora de Castilla', '2', '2019-03-01'),
('8', '7', 'KR 14 # 98 - 74 ', 'All Salad', '22', 'Cebolla Larga Junca x 500', '4', '2019-03-01'),
('8', '7', 'KR 14 # 98 - 74 ', 'All Salad', '27', 'Pimentón Verde', '1', '2019-03-01'),
('8', '7', 'KR 14 # 98 - 74 ', 'All Salad', '5', 'Pimentón Rojo', '1', '2019-03-01'),
('9', '1', 'KR 58 # 93 - 1 ', 'Parrilla y sabor', '22', 'Cebolla Larga Junca x 500', '1', '2019-03-01'),
('15', '9', 'KR 14 # 87 - 20 ', 'Sofia', '28', 'Tomate Larga Vida Maduro', '1', '2019-03-01'),
('10', '1', 'CL 93B # 17 - 12 ', 'restaurante yerbabuena ', '7', 'Cebolla Cabezona Blanca L', '1', '2019-03-01'),
('11', '10', 'KR 68D # 98A - 11 ', 'Luis David', '41', 'Banano', '1', '2019-03-01'),
('11', '10', 'KR 68D # 98A - 11 ', 'Luis David', '19', 'Cebolla Cabezona Blanca S', '6', '2019-03-01'),
('11', '10', 'KR 68D # 98A - 11 ', 'Luis David', '29', 'Cilantro x 500grs', '1', '2019-03-01'),
('11', '10', 'KR 68D # 98A - 11 ', 'Luis David', '17', 'Espinaca Bogotana x 500gr', '1', '2019-03-01'),
('11', '10', 'KR 68D # 98A - 11 ', 'Luis David', '30', 'Fresa Jugo', '1', '2019-03-01'),
('12', '2', 'AC 72 # 20 - 45 ', 'David Carruyo', '7', 'Cebolla Cabezona Blanca L', '1', '2019-03-01'),
('12', '2', 'AC 72 # 20 - 45 ', 'David Carruyo', '25', 'Limón Tahití', '2', '2019-03-01'),
('12', '2', 'AC 72 # 20 - 45 ', 'David Carruyo', '5', 'Pimentón Rojo', '1', '2019-03-01'),
('12', '2', 'AC 72 # 20 - 45 ', 'David Carruyo', '31', 'Papa R-12 Mediana', '25', '2019-03-01'),
('13', '3', 'KR 22 # 122 - 57 ', 'MARIO', '43', 'Banano', '1', '2019-03-01'),
('13', '3', 'KR 22 # 122 - 57 ', 'MARIO', '30', 'Fresa Jugo', '1', '2019-03-01'),
('13', '3', 'KR 22 # 122 - 57 ', 'MARIO', '32', 'Curuba ', '1', '2019-03-01'),
('13', '3', 'KR 22 # 122 - 57 ', 'MARIO', '33', 'Brócoli', '1', '2019-03-01'),
('13', '3', 'KR 22 # 122 - 57 ', 'MARIO', '28', 'Tomate Larga Vida Maduro', '2', '2019-03-01'),
('14', '8', 'KR 88 # 72A - 26 ', 'Harold', '16', 'Acelga', '3', '2019-03-01'),
('14', '8', 'KR 88 # 72A - 26 ', 'Harold', '34', 'Aguacate Hass Pintón', '3', '2019-03-01'),
('14', '8', 'KR 88 # 72A - 26 ', 'Harold', '35', 'Aguacate Hass Maduro ', '3', '2019-03-01'),
('14', '8', 'KR 88 # 72A - 26 ', 'Harold', '12', 'Aguacate Maduro', '1', '2019-03-01'),
('14', '8', 'KR 88 # 72A - 26 ', 'Harold', '36', 'Aguacate Pintón', '1', '2019-03-01');

-- --------------------------------------------------------

--
-- Table structure for table `providers`
--

CREATE TABLE IF NOT EXISTS `providers` (
  `id` varchar(25) NOT NULL,
  `name_prov` varchar(25) NOT NULL,
  `productId` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `providers`
--

INSERT INTO `providers` (`id`, `name_prov`, `productId`) VALUES
('1', 'Ruby', '1'),
('1', 'Ruby', '2'),
('1', 'Ruby', '45'),
('1', 'Ruby', '3'),
('1', 'Ruby', '4'),
('1', 'Ruby', '5'),
('1', 'Ruby', '46'),
('1', 'Ruby', '24'),
('1', 'Ruby', '25'),
('1', 'Ruby', '26'),
('1', 'Ruby', '27'),
('1', 'Raul', '28'),
('1', 'Raul', '47'),
('1', 'Raul', '29'),
('1', 'Raul', '30'),
('1', 'Raul', '31'),
('1', 'Raul', '32'),
('1', 'Raul', '33'),
('1', 'Raul', '34'),
('1', 'Raul', '35'),
('1', 'Raul', '36'),
('1', 'Raul', '16'),
('1', 'Raul', '17'),
('1', 'Angelica', '6'),
('1', 'Angelica', '7'),
('1', 'Angelica', '8'),
('1', 'Angelica', '9'),
('1', 'Angelica', '10'),
('1', 'Angelica', '11'),
('1', 'Angelica', '12'),
('1', 'Angelica', '13'),
('1', 'Angelica', '14'),
('1', 'Angelica', '15'),
('1', 'Angelica', '18'),
('1', 'Angelica', '19'),
('1', 'Angelica', '20'),
('1', 'Angelica', '21'),
('1', 'Angelica', '22'),
('1', 'Angelica', '23');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
